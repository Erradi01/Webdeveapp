import { useState } from "react";
import { motion } from "framer-motion";
import { Plus, Edit, Trash2, Eye, BarChart3, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import Navigation from "@/components/Navigation";
import ProductForm from "@/components/ProductForm";
import AdminAuth from "@/components/AdminAuth";
import ProductDetailsModal from "@/components/ProductDetailsModal";
import ProductAnalytics from "@/components/ProductAnalytics";

interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  image: string;
  category: string;
  featured: boolean;
  tags?: string[];
  longDescription?: string;
  rating?: number;
  downloads?: number;
}

const AdminProducts = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [viewingProduct, setViewingProduct] = useState<Product | null>(null);
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState("All");
  
  const [products, setProducts] = useState<Product[]>([
    {
      id: "1",
      title: "SaaS Website Template Pack",
      description: "Complete website templates for SaaS applications",
      longDescription: "This comprehensive template pack includes everything you need to build a modern SaaS application. Features responsive design, dark mode support, and professional layouts.",
      price: 49,
      image: "/lovable-uploads/c32c6788-5e4a-4fee-afee-604b03113c7f.png",
      category: "Templates",
      featured: true,
      tags: ["React", "TypeScript", "Tailwind"],
      rating: 4.8,
      downloads: 1240
    },
    {
      id: "2",
      title: "React Component Library",
      description: "Professional React components library",
      longDescription: "A complete library of 100+ React components built with TypeScript and Tailwind CSS. Perfect for rapid prototyping and production applications.",
      price: 79,
      image: "/lovable-uploads/21f3edfb-62b5-4e35-9d03-7339d803b980.png",
      category: "Components",
      featured: true,
      tags: ["React", "Components", "UI"],
      rating: 4.9,
      downloads: 856
    }
  ]);

  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  const categories = ["All", "Templates", "Components", "Courses", "Tools"];

  // Filter products based on search and category
  const filteredProducts = products.filter(product => {
    const matchesSearch = product.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === "All" || product.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  const handleSubmit = (productData: Omit<Product, 'id'>) => {
    if (editingProduct) {
      setProducts(prev => prev.map(p => p.id === editingProduct.id ? { 
        ...productData, 
        id: editingProduct.id,
        rating: editingProduct.rating || 4.5,
        downloads: editingProduct.downloads || 0
      } : p));
      setEditingProduct(null);
    } else {
      const newProduct: Product = {
        ...productData,
        id: Date.now().toString(),
        rating: 4.5,
        downloads: 0
      };
      setProducts(prev => [...prev, newProduct]);
      setIsAddingProduct(false);
    }
  };

  const handleEdit = (product: Product) => {
    setEditingProduct(product);
  };

  const handleDelete = (productId: string) => {
    if (confirm("Are you sure you want to delete this product?")) {
      setProducts(prev => prev.filter(p => p.id !== productId));
    }
  };

  const handleCancel = () => {
    setIsAddingProduct(false);
    setEditingProduct(null);
  };

  // Show authentication screen if not authenticated
  if (!isAuthenticated) {
    return <AdminAuth onAuthenticated={() => setIsAuthenticated(true)} />;
  }

  return (
    <div className="min-h-screen bg-black text-foreground">
      <Navigation />
      
      <main className="pt-32 pb-20">
        <div className="container px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="flex justify-between items-center mb-8"
          >
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2">Admin - Digital Products</h1>
              <p className="text-muted-foreground">Manage your digital products and inventory</p>
            </div>

            <div className="flex gap-2">
              <Button 
                variant="outline" 
                onClick={() => setShowAnalytics(!showAnalytics)}
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                Analytics
              </Button>
              <Dialog open={isAddingProduct} onOpenChange={setIsAddingProduct}>
                <DialogTrigger asChild>
                  <Button className="button-gradient">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Product
                  </Button>
                </DialogTrigger>
                <DialogContent className="glass max-w-6xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Add New Product</DialogTitle>
                  </DialogHeader>
                  <ProductForm 
                    categories={categories.filter(c => c !== "All")}
                    onSubmit={handleSubmit}
                    onCancel={handleCancel}
                  />
                </DialogContent>
              </Dialog>
            </div>
          </motion.div>

          {/* Analytics Section */}
          {showAnalytics && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className="mb-8"
            >
              <ProductAnalytics products={products} />
            </motion.div>
          )}

          {/* Search and Filter */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="flex flex-col md:flex-row gap-4 mb-8"
          >
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </motion.div>

          {/* Products Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="glass glass-hover">
                  <div className="relative">
                    <img
                      src={product.image}
                      alt={product.title}
                      className="w-full h-32 object-cover rounded-t-lg"
                    />
                    {product.featured && (
                      <span className="absolute top-2 left-2 bg-primary text-primary-foreground px-2 py-1 rounded text-xs">
                        Featured
                      </span>
                    )}
                  </div>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">{product.title}</CardTitle>
                    <p className="text-sm text-muted-foreground">{product.category}</p>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground text-sm mb-3 line-clamp-2">
                      {product.description}
                    </p>
                    {product.tags && (
                      <div className="flex flex-wrap gap-1 mb-3">
                        {product.tags.map((tag) => (
                          <span key={tag} className="bg-secondary text-secondary-foreground px-2 py-1 rounded text-xs">
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-lg font-bold text-primary">${product.price}</span>
                      <div className="text-sm text-muted-foreground">
                        {product.downloads || 0} downloads
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setViewingProduct(product)}
                      >
                        <Eye className="w-3 h-3" />
                      </Button>
                      <Dialog open={editingProduct?.id === product.id} onOpenChange={(open) => !open && setEditingProduct(null)}>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm" onClick={() => handleEdit(product)}>
                            <Edit className="w-3 h-3" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="glass max-w-6xl max-h-[90vh] overflow-y-auto">
                          <DialogHeader>
                            <DialogTitle>Edit Product</DialogTitle>
                          </DialogHeader>
                          <ProductForm 
                            product={editingProduct}
                            categories={categories.filter(c => c !== "All")}
                            onSubmit={handleSubmit}
                            onCancel={handleCancel}
                          />
                        </DialogContent>
                      </Dialog>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDelete(product.id)}
                        className="text-red-500 hover:text-red-400"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-20">
              <p className="text-muted-foreground">
                {searchTerm || filterCategory !== "All" 
                  ? "No products found matching your criteria." 
                  : "No products found. Add your first product to get started."
                }
              </p>
            </div>
          )}
        </div>
      </main>

      {/* Product Details Modal */}
      {viewingProduct && (
        <ProductDetailsModal
          product={viewingProduct}
          onClose={() => setViewingProduct(null)}
        />
      )}
    </div>
  );
};

export default AdminProducts;
