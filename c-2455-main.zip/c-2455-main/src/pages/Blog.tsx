
import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Calendar, User, Search, Tag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

interface BlogPost {
  id: string;
  title: string;
  content: string;
  published: string;
  url: string;
  author: {
    displayName: string;
  };
  labels?: string[];
}

const Blog = () => {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [filteredPosts, setFilteredPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        // Mock data - replace with actual Blogger API call
        const mockPosts: BlogPost[] = [
          {
            id: "1",
            title: "Getting Started with SaaS Development",
            content: "Learn the fundamentals of building successful SaaS applications with modern web technologies. This comprehensive guide covers everything from initial planning to deployment...",
            published: "2024-01-15T10:00:00Z",
            url: "#",
            author: { displayName: "John Doe" },
            labels: ["SaaS", "Development", "Tutorial"]
          },
          {
            id: "2",
            title: "Best Practices for Web Application Security",
            content: "Discover essential security measures every web developer should implement in their applications. Security is not optional in today's digital landscape...",
            published: "2024-01-10T14:30:00Z",
            url: "#",
            author: { displayName: "Jane Smith" },
            labels: ["Security", "Web Development", "Best Practices"]
          },
          {
            id: "3",
            title: "The Future of AI in Web Development",
            content: "Explore how artificial intelligence is transforming the way we build and maintain web applications. From code generation to automated testing...",
            published: "2024-01-05T09:15:00Z",
            url: "#",
            author: { displayName: "Mike Johnson" },
            labels: ["AI", "Future Tech", "Innovation"]
          },
          {
            id: "4",
            title: "Building Responsive Design Systems",
            content: "Creating consistent and scalable design systems that work across all devices and platforms. Learn about component libraries and design tokens...",
            published: "2024-01-01T16:45:00Z",
            url: "#",
            author: { displayName: "Sarah Wilson" },
            labels: ["Design", "UI/UX", "Frontend"]
          }
        ];
        
        setPosts(mockPosts);
        setFilteredPosts(mockPosts);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching blog posts:", error);
        setLoading(false);
      }
    };

    fetchPosts();
  }, []);

  useEffect(() => {
    const filtered = posts.filter(post =>
      post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.labels?.some(label => label.toLowerCase().includes(searchTerm.toLowerCase()))
    );
    setFilteredPosts(filtered);
  }, [searchTerm, posts]);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const stripHtml = (html: string) => {
    const tmp = document.createElement("div");
    tmp.innerHTML = html;
    return tmp.textContent || tmp.innerText || "";
  };

  return (
    <div className="min-h-screen bg-black text-foreground">
      <Navigation />
      
      <main className="pt-32 pb-20">
        <div className="container px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-16"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">Our Blog</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              Insights, tutorials, and industry trends in web development and SaaS.
            </p>
            
            <div className="max-w-md mx-auto relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                type="text"
                placeholder="Search blog posts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 glass"
              />
            </div>
          </motion.div>

          {loading ? (
            <div className="text-center py-20">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
              <p className="mt-4 text-muted-foreground">Loading blog posts...</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredPosts.map((post, index) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="glass glass-hover h-full">
                    <CardHeader>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                        <Calendar className="w-4 h-4" />
                        {formatDate(post.published)}
                      </div>
                      <h2 className="text-xl font-semibold line-clamp-2">{post.title}</h2>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground mb-4 line-clamp-3">
                        {stripHtml(post.content)}
                      </p>
                      
                      {post.labels && (
                        <div className="flex flex-wrap gap-2 mb-4">
                          {post.labels.slice(0, 3).map((label) => (
                            <span
                              key={label}
                              className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-primary/10 text-primary text-xs"
                            >
                              <Tag className="w-3 h-3" />
                              {label}
                            </span>
                          ))}
                        </div>
                      )}
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <User className="w-4 h-4" />
                          {post.author.displayName}
                        </div>
                        <Button variant="ghost" size="sm">
                          Read More
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}

          {filteredPosts.length === 0 && !loading && (
            <div className="text-center py-20">
              <p className="text-muted-foreground">No blog posts found matching your search.</p>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Blog;
