
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, ShoppingCart, Star, Download, Eye, Calendar, Tag, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { FullPaymentFlow } from "@/components/payment/FullPaymentFlow";

interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  image: string;
  category: string;
  rating: number;
  downloads: number;
  featured: boolean;
  tags?: string[];
  longDescription?: string;
  features?: string[];
  downloadUrl?: string;
}

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [showPaymentFlow, setShowPaymentFlow] = useState(false);
  const [isPurchased, setIsPurchased] = useState(false);

  // Mock products data - in a real app, this would come from an API
  const products: Product[] = [
    {
      id: "1",
      title: "SaaS Website Template Pack",
      description: "Complete website templates for SaaS applications including landing pages, dashboards, and admin panels.",
      price: 49,
      image: "/lovable-uploads/c32c6788-5e4a-4fee-afee-604b03113c7f.png",
      category: "Templates",
      rating: 4.8,
      downloads: 1240,
      featured: true,
      tags: ["React", "TypeScript", "Tailwind"],
      longDescription: "This comprehensive template pack includes everything you need to build a modern SaaS application. Features responsive design, dark mode support, authentication pages, pricing sections, and more. Built with React, TypeScript, and Tailwind CSS for optimal performance and maintainability.",
      features: [
        "5 Complete SaaS Templates",
        "Responsive Design",
        "Dark Mode Support",
        "TypeScript Implementation",
        "Tailwind CSS Styling",
        "Authentication Pages",
        "Dashboard Components",
        "Pricing Section Templates",
        "Admin Panel Interface",
        "Documentation Included"
      ],
      downloadUrl: "/downloads/saas-template-pack.zip"
    },
    {
      id: "2",
      title: "React Component Library",
      description: "Professional React components library with 100+ customizable components for rapid development.",
      price: 79,
      image: "/lovable-uploads/21f3edfb-62b5-4e35-9d03-7339d803b980.png",
      category: "Components",
      rating: 4.9,
      downloads: 856,
      featured: true,
      tags: ["React", "Components", "UI"],
      longDescription: "A complete component library featuring over 100 professionally designed React components. Includes forms, navigation, data display, feedback components, and more. Fully customizable with TypeScript support and comprehensive documentation.",
      features: [
        "100+ React Components",
        "TypeScript Support",
        "Comprehensive Documentation",
        "Customizable Themes",
        "Form Components",
        "Navigation Elements",
        "Data Display Components",
        "Feedback Components",
        "Storybook Integration",
        "NPM Package Included"
      ],
      downloadUrl: "/downloads/react-component-library.zip"
    }
  ];

  useEffect(() => {
    const foundProduct = products.find(p => p.id === id);
    setProduct(foundProduct || null);
    
    // Check if user has already purchased this product (localStorage for demo)
    const purchased = localStorage.getItem(`purchased_${id}`) === 'true';
    setIsPurchased(purchased);
  }, [id]);

  const handlePurchase = () => {
    setShowPaymentFlow(true);
  };

  const handlePaymentSuccess = () => {
    setShowPaymentFlow(false);
    setIsPurchased(true);
    localStorage.setItem(`purchased_${product?.id}`, 'true');
  };

  const handleDownload = () => {
    if (product?.downloadUrl) {
      // Create a temporary link to trigger download
      const link = document.createElement('a');
      link.href = product.downloadUrl;
      link.download = `${product.title.replace(/\s+/g, '-').toLowerCase()}.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  if (!product) {
    return (
      <div className="min-h-screen bg-black text-foreground">
        <Navigation />
        <main className="pt-32 pb-20">
          <div className="container px-4 text-center">
            <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
            <Button onClick={() => navigate('/products')} variant="outline">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Products
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-foreground">
      <Navigation />
      
      <main className="pt-32 pb-20">
        <div className="container px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Button 
              onClick={() => navigate('/products')} 
              variant="ghost" 
              className="mb-8"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Products
            </Button>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-12">
              {/* Product Image */}
              <div>
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-96 object-cover rounded-lg"
                />
              </div>

              {/* Product Info */}
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <Badge variant="secondary">{product.category}</Badge>
                  {product.featured && (
                    <Badge className="bg-primary">Featured</Badge>
                  )}
                </div>

                <h1 className="text-4xl font-bold mb-4">{product.title}</h1>
                
                <div className="flex items-center gap-4 mb-6">
                  <div className="flex items-center gap-1">
                    <Star className="w-5 h-5 text-yellow-500 fill-current" />
                    <span className="text-lg font-medium">{product.rating}</span>
                    <span className="text-muted-foreground">(120 reviews)</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Download className="w-5 h-5 text-muted-foreground" />
                    <span className="text-muted-foreground">
                      {product.category === "Photography" ? `${product.downloads} bookings` : `${product.downloads} downloads`}
                    </span>
                  </div>
                </div>

                <p className="text-lg text-muted-foreground mb-6">
                  {product.description}
                </p>

                {product.tags && (
                  <div className="mb-6">
                    <div className="flex items-center gap-2 mb-2">
                      <Tag className="w-4 h-4" />
                      <span className="font-medium">Tags</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {product.tags.map((tag) => (
                        <Badge key={tag} variant="outline">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between mb-8">
                  <div className="text-4xl font-bold text-primary">${product.price}</div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Calendar className="w-4 h-4" />
                    <span>Updated 2 weeks ago</span>
                  </div>
                </div>

                {isPurchased ? (
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                      <Check className="w-5 h-5 text-green-500" />
                      <span className="text-green-500">You own this product</span>
                    </div>
                    <Button 
                      onClick={handleDownload}
                      className="w-full button-gradient"
                      size="lg"
                    >
                      <Download className="w-5 h-5 mr-2" />
                      Download Files
                    </Button>
                  </div>
                ) : (
                  <Button 
                    onClick={handlePurchase}
                    className="w-full button-gradient"
                    size="lg"
                  >
                    <ShoppingCart className="w-5 h-5 mr-2" />
                    {product.category === "Photography" ? "Book Session" : "Purchase & Download"}
                  </Button>
                )}
              </div>
            </div>

            {/* Product Details */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Description */}
              <div className="lg:col-span-2">
                <Card className="glass">
                  <CardHeader>
                    <CardTitle>Product Details</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground leading-relaxed mb-6">
                      {product.longDescription}
                    </p>
                    
                    {product.features && (
                      <div>
                        <h3 className="text-lg font-semibold mb-4">What's Included</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                          {product.features.map((feature, index) => (
                            <div key={index} className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-500" />
                              <span className="text-sm">{feature}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Stats */}
              <div>
                <Card className="glass">
                  <CardHeader>
                    <CardTitle>Product Stats</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Rating</span>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-yellow-500 fill-current" />
                        <span>{product.rating}/5</span>
                      </div>
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Downloads</span>
                      <span>{product.downloads.toLocaleString()}</span>
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Category</span>
                      <Badge variant="secondary">{product.category}</Badge>
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Last Updated</span>
                      <span className="text-sm">2 weeks ago</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </motion.div>
        </div>
      </main>

      <Footer />

      {/* Payment Flow Modal */}
      {showPaymentFlow && (
        <FullPaymentFlow
          isOpen={showPaymentFlow}
          onClose={() => setShowPaymentFlow(false)}
          onSuccess={handlePaymentSuccess}
          product={product}
        />
      )}
    </div>
  );
};

export default ProductDetail;
