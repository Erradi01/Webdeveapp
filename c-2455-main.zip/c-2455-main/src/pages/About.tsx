
import { motion } from "framer-motion";
import { Users, Target, Award, Heart } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

const About = () => {
  const values = [
    {
      icon: Users,
      title: "Community First",
      description: "We believe in building a strong community of developers who support and learn from each other."
    },
    {
      icon: Target,
      title: "Quality Focus",
      description: "Every product and service we offer is crafted with attention to detail and high standards."
    },
    {
      icon: Award,
      title: "Innovation",
      description: "We stay ahead of the curve by embracing new technologies and best practices."
    },
    {
      icon: Heart,
      title: "Passion Driven",
      description: "Our love for web development drives us to create solutions that truly make a difference."
    }
  ];

  const team = [
    {
      name: "Alex Johnson",
      role: "Founder & CEO",
      bio: "Full-stack developer with 10+ years of experience in building scalable web applications.",
      image: "/lovable-uploads/c32c6788-5e4a-4fee-afee-604b03113c7f.png"
    },
    {
      name: "Sarah Chen",
      role: "Lead Developer",
      bio: "Frontend specialist passionate about creating beautiful and intuitive user experiences.",
      image: "/lovable-uploads/21f3edfb-62b5-4e35-9d03-7339d803b980.png"
    },
    {
      name: "Mike Rodriguez",
      role: "Backend Engineer",
      bio: "Expert in cloud architecture and API development with a focus on performance and scalability.",
      image: "/lovable-uploads/c32c6788-5e4a-4fee-afee-604b03113c7f.png"
    }
  ];

  return (
    <div className="min-h-screen bg-black text-foreground">
      <Navigation />
      
      <main className="pt-32 pb-20">
        <div className="container px-4">
          {/* Hero Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-20"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">About Us</h1>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              We're a team of passionate web developers dedicated to creating innovative SaaS solutions 
              that empower businesses and developers to achieve their goals.
            </p>
          </motion.div>

          {/* Story Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mb-20"
          >
            <div className="glass glass-hover rounded-xl p-8 md:p-12">
              <h2 className="text-3xl font-bold mb-6">Our Story</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div>
                  <p className="text-muted-foreground mb-4">
                    Founded in 2020, webdeveapp started as a small project to help fellow developers 
                    build better web applications faster. What began as a simple idea has grown into 
                    a comprehensive platform offering SaaS solutions, digital products, and educational resources.
                  </p>
                  <p className="text-muted-foreground mb-4">
                    Our journey has been driven by a simple belief: great software should be accessible 
                    to everyone. We've helped thousands of developers and businesses transform their 
                    ideas into successful digital products.
                  </p>
                  <p className="text-muted-foreground">
                    Today, we continue to innovate and expand our offerings, always keeping our 
                    community at the heart of everything we do.
                  </p>
                </div>
                <div className="relative">
                  <img
                    src="/lovable-uploads/c32c6788-5e4a-4fee-afee-604b03113c7f.png"
                    alt="Our Journey"
                    className="rounded-lg w-full"
                  />
                </div>
              </div>
            </div>
          </motion.div>

          {/* Values Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mb-20"
          >
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Our Values</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                These core values guide everything we do and shape how we build products and serve our community.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {values.map((value, index) => (
                <motion.div
                  key={value.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 + index * 0.1 }}
                >
                  <Card className="glass glass-hover h-full">
                    <CardContent className="p-6 text-center">
                      <value.icon className="w-12 h-12 text-primary mx-auto mb-4" />
                      <h3 className="text-xl font-semibold mb-3">{value.title}</h3>
                      <p className="text-muted-foreground">{value.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Team Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="mb-20"
          >
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Meet Our Team</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                The talented individuals behind our products and services.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {team.map((member, index) => (
                <motion.div
                  key={member.name}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.7 + index * 0.1 }}
                >
                  <Card className="glass glass-hover">
                    <CardContent className="p-6 text-center">
                      <img
                        src={member.image}
                        alt={member.name}
                        className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
                      />
                      <h3 className="text-xl font-semibold mb-1">{member.name}</h3>
                      <p className="text-primary font-medium mb-3">{member.role}</p>
                      <p className="text-muted-foreground text-sm">{member.bio}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Contact Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
          >
            <div className="glass glass-hover rounded-xl p-8 md:p-12 text-center">
              <h2 className="text-3xl font-bold mb-4">Get In Touch</h2>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                Have questions about our products or services? We'd love to hear from you. 
                Reach out to us and let's start a conversation.
              </p>
              <div className="space-y-2 text-muted-foreground">
                <p>Email: hello@webdeveapp.web.app</p>
                <p>Phone: +1 (555) 123-4567</p>
                <p>Address: 123 Developer Street, Tech City, TC 12345</p>
              </div>
            </div>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default About;
