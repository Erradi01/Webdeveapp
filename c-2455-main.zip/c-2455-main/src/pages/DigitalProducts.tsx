import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { ShoppingCart, Star, Download, Lock, Filter, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import EnhancedProductFilter from "@/components/EnhancedProductFilter";
import ProductPagination from "@/components/ProductPagination";
import ProductDetailsModal from "@/components/ProductDetailsModal";

interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  image: string;
  category: string;
  rating: number;
  downloads: number;
  featured: boolean;
  tags?: string[];
  longDescription?: string;
}

const DigitalProducts = () => {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(12);

  // Mock products data with more examples
  const products: Product[] = [
    {
      id: "1",
      title: "SaaS Website Template Pack",
      description: "Complete website templates for SaaS applications including landing pages, dashboards, and admin panels.",
      price: 49,
      image: "/lovable-uploads/c32c6788-5e4a-4fee-afee-604b03113c7f.png",
      category: "Templates",
      rating: 4.8,
      downloads: 1240,
      featured: true,
      tags: ["React", "TypeScript", "Tailwind"],
      longDescription: "This comprehensive template pack includes everything you need to build a modern SaaS application. Features responsive design, dark mode support, authentication pages, pricing sections, and more. Built with React, TypeScript, and Tailwind CSS for optimal performance and maintainability."
    },
    {
      id: "2",
      title: "React Component Library",
      description: "Professional React components library with 100+ customizable components for rapid development.",
      price: 79,
      image: "/lovable-uploads/21f3edfb-62b5-4e35-9d03-7339d803b980.png",
      category: "Components",
      rating: 4.9,
      downloads: 856,
      featured: true,
      tags: ["React", "Components", "UI"],
      longDescription: "A complete component library featuring over 100 professionally designed React components. Includes forms, navigation, data display, feedback components, and more. Fully customizable with TypeScript support and comprehensive documentation."
    },
    {
      id: "3",
      title: "Web Development Course",
      description: "Complete web development course covering modern technologies, best practices, and real-world projects.",
      price: 199,
      image: "/lovable-uploads/c32c6788-5e4a-4fee-afee-604b03113c7f.png",
      category: "Courses",
      rating: 4.7,
      downloads: 523,
      featured: false,
      tags: ["Education", "JavaScript", "Full-Stack"],
      longDescription: "Master web development with this comprehensive course covering HTML, CSS, JavaScript, React, Node.js, and modern deployment strategies. Includes hands-on projects and real-world applications."
    },
    {
      id: "4",
      title: "API Documentation Tool",
      description: "Professional API documentation generator with interactive examples and beautiful themes.",
      price: 39,
      image: "/lovable-uploads/21f3edfb-62b5-4e35-9d03-7339d803b980.png",
      category: "Tools",
      rating: 4.6,
      downloads: 392,
      featured: false,
      tags: ["API", "Documentation", "Developer Tools"],
      longDescription: "Generate beautiful, interactive API documentation with ease. Features automatic code generation, interactive examples, multiple themes, and seamless integration with popular frameworks."
    },
    {
      id: "5",
      title: "E-commerce Template Bundle",
      description: "Modern e-commerce templates with shopping cart, checkout, and admin dashboard.",
      price: 89,
      image: "/lovable-uploads/c32c6788-5e4a-4fee-afee-604b03113c7f.png",
      category: "Templates",
      rating: 4.5,
      downloads: 678,
      featured: true,
      tags: ["E-commerce", "React", "Payment"],
      longDescription: "Complete e-commerce solution with product listings, shopping cart, secure checkout, and comprehensive admin dashboard. Includes payment integration and inventory management."
    },
    {
      id: "6",
      title: "Design System Kit",
      description: "Comprehensive design system with components, tokens, and guidelines for consistent UI.",
      price: 129,
      image: "/lovable-uploads/21f3edfb-62b5-4e35-9d03-7339d803b980.png",
      category: "Components",
      rating: 4.8,
      downloads: 445,
      featured: false,
      tags: ["Design System", "UI Kit", "Figma"],
      longDescription: "Professional design system including color palettes, typography, components, and detailed usage guidelines. Available in Figma and code formats."
    }
  ];

  const categories = ["All", "Templates", "Components", "Courses", "Tools"];
  const availableTags = [...new Set(products.flatMap(p => p.tags || []))];

  const [filters, setFilters] = useState({
    category: "All",
    search: "",
    sortBy: "featured",
    priceRange: "all",
    featured: "all",
    tags: [] as string[]
  });

  const filteredAndSortedProducts = useMemo(() => {
    let filtered = products.filter(product => {
      const matchesCategory = filters.category === "All" || product.category === filters.category;
      const matchesSearch = filters.search === "" || 
        product.title.toLowerCase().includes(filters.search.toLowerCase()) ||
        product.description.toLowerCase().includes(filters.search.toLowerCase()) ||
        product.tags?.some(tag => tag.toLowerCase().includes(filters.search.toLowerCase()));
      
      const matchesPrice = filters.priceRange === "all" || (() => {
        switch (filters.priceRange) {
          case "0-25": return product.price <= 25;
          case "25-50": return product.price > 25 && product.price <= 50;
          case "50-100": return product.price > 50 && product.price <= 100;
          case "100+": return product.price > 100;
          default: return true;
        }
      })();

      const matchesFeatured = filters.featured === "all" || 
        (filters.featured === "featured" && product.featured) ||
        (filters.featured === "regular" && !product.featured);

      const matchesTags = filters.tags.length === 0 || 
        filters.tags.some(tag => product.tags?.includes(tag));
      
      return matchesCategory && matchesSearch && matchesPrice && matchesFeatured && matchesTags;
    });

    // Sort products
    filtered.sort((a, b) => {
      switch (filters.sortBy) {
        case "price-low": return a.price - b.price;
        case "price-high": return b.price - a.price;
        case "rating": return b.rating - a.rating;
        case "downloads": return b.downloads - a.downloads;
        case "newest": return b.id.localeCompare(a.id);
        case "featured":
        default: return b.featured === a.featured ? 0 : b.featured ? 1 : -1;
      }
    });

    return filtered;
  }, [products, filters]);

  // Pagination
  const totalPages = Math.ceil(filteredAndSortedProducts.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedProducts = filteredAndSortedProducts.slice(startIndex, startIndex + itemsPerPage);
  const featuredProducts = paginatedProducts.filter(product => product.featured);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleItemsPerPageChange = (items: number) => {
    setItemsPerPage(items);
    setCurrentPage(1);
  };

  return (
    <div className="min-h-screen bg-black text-foreground">
      <Navigation />
      
      <main className="pt-32 pb-20">
        <div className="container px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-16"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">Digital Products</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Premium digital products to accelerate your development workflow and business growth.
            </p>
          </motion.div>

          {/* Enhanced Product Filter */}
          <EnhancedProductFilter 
            categories={categories}
            availableTags={availableTags}
            onFilterChange={setFilters}
            viewMode={viewMode}
            onViewModeChange={setViewMode}
            resultsCount={filteredAndSortedProducts.length}
          />

          {/* Featured Products */}
          {featuredProducts.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="mb-16"
            >
              <h2 className="text-2xl font-bold mb-8">Featured Products</h2>
              <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 md:grid-cols-2' : 'grid-cols-1'} gap-8`}>
                {featuredProducts.map((product) => (
                  <Card key={product.id} className="glass glass-hover overflow-hidden">
                    <div className="relative">
                      <img
                        src={product.image}
                        alt={product.title}
                        className="w-full h-48 object-cover"
                      />
                      <Badge className="absolute top-4 left-4 bg-primary">
                        Featured
                      </Badge>
                    </div>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-xl mb-2">{product.title}</CardTitle>
                          <Badge variant="secondary">{product.category}</Badge>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-primary">${product.price}</div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground mb-4">{product.description}</p>
                      {product.tags && (
                        <div className="flex flex-wrap gap-1 mb-4">
                          {product.tags.map((tag) => (
                            <Badge key={tag} variant="outline" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      )}
                      <div className="flex items-center gap-4 mb-4">
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 text-yellow-500 fill-current" />
                          <span className="text-sm">{product.rating}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Download className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">{product.downloads} downloads</span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="flex-1"
                          asChild
                        >
                          <a href={`/products/${product.id}`}>
                            View Details
                          </a>
                        </Button>
                        <Button 
                          size="sm" 
                          className="flex-1 button-gradient"
                          onClick={() => setSelectedProduct(product)}
                        >
                          <ShoppingCart className="w-4 h-4 mr-2" />
                          Buy
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </motion.div>
          )}

          {/* All Products */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <h2 className="text-2xl font-bold mb-8">
              All Products ({filteredAndSortedProducts.length})
            </h2>
            <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1'} gap-8`}>
              {paginatedProducts.map((product) => (
                <Card key={product.id} className="glass glass-hover overflow-hidden">
                  <div className="relative">
                    <img
                      src={product.image}
                      alt={product.title}
                      className={`w-full ${viewMode === 'grid' ? 'h-32' : 'h-48'} object-cover`}
                    />
                    {product.featured && (
                      <Badge className="absolute top-2 left-2 bg-primary text-xs">
                        Featured
                      </Badge>
                    )}
                  </div>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">{product.title}</CardTitle>
                    <Badge variant="secondary" className="w-fit">{product.category}</Badge>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground text-sm mb-3 line-clamp-2">
                      {product.description}
                    </p>
                    {product.tags && (
                      <div className="flex flex-wrap gap-1 mb-3">
                        {product.tags.slice(0, 2).map((tag) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                        {product.tags.length > 2 && (
                          <Badge variant="outline" className="text-xs">
                            +{product.tags.length - 2}
                          </Badge>
                        )}
                      </div>
                    )}
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-1">
                        <Star className="w-3 h-3 text-yellow-500 fill-current" />
                        <span className="text-sm">{product.rating}</span>
                      </div>
                      <div className="text-lg font-bold text-primary">${product.price}</div>
                    </div>
                    <div className="flex gap-1">
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="flex-1"
                        asChild
                      >
                        <a href={`/products/${product.id}`}>
                          Details
                        </a>
                      </Button>
                      <Button size="sm" className="flex-1 button-gradient">
                        <ShoppingCart className="w-3 h-3 mr-1" />
                        Buy
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredAndSortedProducts.length === 0 && (
              <div className="text-center py-20">
                <p className="text-muted-foreground">No products found matching your criteria.</p>
              </div>
            )}

            {/* Pagination */}
            {filteredAndSortedProducts.length > 0 && (
              <ProductPagination
                currentPage={currentPage}
                totalPages={totalPages}
                itemsPerPage={itemsPerPage}
                totalItems={filteredAndSortedProducts.length}
                onPageChange={handlePageChange}
                onItemsPerPageChange={handleItemsPerPageChange}
              />
            )}
          </motion.div>

          {/* Admin Access */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="mt-20 text-center"
          >
            <Card className="glass glass-hover max-w-md mx-auto">
              <CardContent className="p-6">
                <Lock className="w-12 h-12 text-primary mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Admin Access</h3>
                <p className="text-muted-foreground mb-4">
                  Manage your digital products and add new items to the store.
                </p>
                <Button asChild variant="outline">
                  <a href="/admin/products">
                    Access Admin Panel
                  </a>
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </main>

      <Footer />

      {/* Product Details Modal */}
      {selectedProduct && (
        <ProductDetailsModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
        />
      )}
    </div>
  );
};

export default DigitalProducts;
