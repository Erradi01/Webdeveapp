
import { motion } from "framer-motion";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

const TermsOfService = () => {
  return (
    <div className="min-h-screen bg-black text-foreground">
      <Navigation />
      
      <main className="pt-32 pb-20">
        <div className="container px-4 max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Terms of Service</h1>
            <p className="text-muted-foreground mb-8">Last updated: {new Date().toLocaleDateString()}</p>
            
            <div className="prose prose-invert max-w-none">
              <div className="glass glass-hover rounded-xl p-8 mb-8">
                <h2 className="text-2xl font-semibold mb-4">1. Acceptance of Terms</h2>
                <p className="text-muted-foreground">
                  By accessing and using our website and services, you accept and agree to be bound 
                  by the terms and provision of this agreement. If you do not agree to abide by 
                  the above, please do not use this service.
                </p>
              </div>

              <div className="glass glass-hover rounded-xl p-8 mb-8">
                <h2 className="text-2xl font-semibold mb-4">2. Description of Service</h2>
                <p className="text-muted-foreground mb-4">
                  We provide SaaS solutions, digital products, and web development services. 
                  Our services include but are not limited to:
                </p>
                <ul className="list-disc list-inside text-muted-foreground space-y-2">
                  <li>Website templates and components</li>
                  <li>Educational courses and tutorials</li>
                  <li>Software tools and applications</li>
                  <li>Consulting and development services</li>
                </ul>
              </div>

              <div className="glass glass-hover rounded-xl p-8 mb-8">
                <h2 className="text-2xl font-semibold mb-4">3. User Accounts</h2>
                <p className="text-muted-foreground mb-4">
                  To access certain features of our service, you may be required to create an account.
                </p>
                <ul className="list-disc list-inside text-muted-foreground space-y-2">
                  <li>You must provide accurate and complete information</li>
                  <li>You are responsible for maintaining account security</li>
                  <li>You must notify us immediately of unauthorized access</li>
                  <li>You are responsible for all activities under your account</li>
                </ul>
              </div>

              <div className="glass glass-hover rounded-xl p-8 mb-8">
                <h2 className="text-2xl font-semibold mb-4">4. Payment Terms</h2>
                <p className="text-muted-foreground mb-4">
                  For paid services and products:
                </p>
                <ul className="list-disc list-inside text-muted-foreground space-y-2">
                  <li>Payment is due at the time of purchase</li>
                  <li>All prices are in USD unless otherwise specified</li>
                  <li>Refunds are subject to our refund policy</li>
                  <li>We reserve the right to change prices with notice</li>
                </ul>
              </div>

              <div className="glass glass-hover rounded-xl p-8 mb-8">
                <h2 className="text-2xl font-semibold mb-4">5. Intellectual Property Rights</h2>
                <p className="text-muted-foreground mb-4">
                  Our service and its original content, features, and functionality are owned by us 
                  and are protected by international copyright, trademark, and other intellectual property laws.
                </p>
                <ul className="list-disc list-inside text-muted-foreground space-y-2">
                  <li>You may not copy, modify, or distribute our content without permission</li>
                  <li>Licensed products are for your use according to the license terms</li>
                  <li>You retain rights to content you create using our services</li>
                </ul>
              </div>

              <div className="glass glass-hover rounded-xl p-8 mb-8">
                <h2 className="text-2xl font-semibold mb-4">6. Prohibited Uses</h2>
                <p className="text-muted-foreground mb-4">
                  You may not use our service:
                </p>
                <ul className="list-disc list-inside text-muted-foreground space-y-2">
                  <li>For any unlawful purpose</li>
                  <li>To violate any applicable laws or regulations</li>
                  <li>To transmit malicious code or viruses</li>
                  <li>To infringe upon intellectual property rights</li>
                  <li>To harass, abuse, or harm others</li>
                </ul>
              </div>

              <div className="glass glass-hover rounded-xl p-8 mb-8">
                <h2 className="text-2xl font-semibold mb-4">7. Disclaimer of Warranties</h2>
                <p className="text-muted-foreground">
                  Our service is provided "as is" and "as available" without any warranties 
                  of any kind, either express or implied. We do not warrant that the service 
                  will be uninterrupted, timely, secure, or error-free.
                </p>
              </div>

              <div className="glass glass-hover rounded-xl p-8 mb-8">
                <h2 className="text-2xl font-semibold mb-4">8. Limitation of Liability</h2>
                <p className="text-muted-foreground">
                  In no event shall we be liable for any indirect, incidental, special, 
                  consequential, or punitive damages arising out of or related to your use 
                  of the service.
                </p>
              </div>

              <div className="glass glass-hover rounded-xl p-8 mb-8">
                <h2 className="text-2xl font-semibold mb-4">9. Termination</h2>
                <p className="text-muted-foreground">
                  We may terminate or suspend your account and access to the service immediately, 
                  without prior notice, for conduct that we believe violates these Terms of Service.
                </p>
              </div>

              <div className="glass glass-hover rounded-xl p-8">
                <h2 className="text-2xl font-semibold mb-4">10. Contact Information</h2>
                <p className="text-muted-foreground">
                  If you have any questions about these Terms of Service, please contact us at:
                  <br />
                  Email: legal@webdeveapp.web.app
                  <br />
                  Address: [Your Business Address]
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default TermsOfService;
