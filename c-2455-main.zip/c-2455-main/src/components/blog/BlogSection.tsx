
import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Calendar, User, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";

interface BlogPost {
  id: string;
  title: string;
  content: string;
  published: string;
  url: string;
  author: {
    displayName: string;
  };
  labels?: string[];
}

const BlogSection = () => {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);

  // Replace with your Blogger API key and blog ID
  const BLOGGER_API_KEY = "YOUR_BLOGGER_API_KEY";
  const BLOG_ID = "YOUR_BLOG_ID";

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        // For demo purposes, using mock data. Replace with actual API call:
        // const response = await fetch(`https://www.googleapis.com/blogger/v3/blogs/${BLOG_ID}/posts?key=${BLOGGER_API_KEY}&maxResults=3`);
        
        // Mock data for demonstration
        const mockPosts: BlogPost[] = [
          {
            id: "1",
            title: "Getting Started with SaaS Development",
            content: "Learn the fundamentals of building successful SaaS applications with modern web technologies...",
            published: "2024-01-15T10:00:00Z",
            url: "#",
            author: { displayName: "John Doe" },
            labels: ["SaaS", "Development"]
          },
          {
            id: "2",
            title: "Best Practices for Web Application Security",
            content: "Discover essential security measures every web developer should implement in their applications...",
            published: "2024-01-10T14:30:00Z",
            url: "#",
            author: { displayName: "Jane Smith" },
            labels: ["Security", "Web Development"]
          },
          {
            id: "3",
            title: "The Future of AI in Web Development",
            content: "Explore how artificial intelligence is transforming the way we build and maintain web applications...",
            published: "2024-01-05T09:15:00Z",
            url: "#",
            author: { displayName: "Mike Johnson" },
            labels: ["AI", "Future Tech"]
          }
        ];
        
        setPosts(mockPosts);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching blog posts:", error);
        setLoading(false);
      }
    };

    fetchPosts();
  }, []);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const stripHtml = (html: string) => {
    const tmp = document.createElement("div");
    tmp.innerHTML = html;
    return tmp.textContent || tmp.innerText || "";
  };

  if (loading) {
    return (
      <section className="container px-4 py-20">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading blog posts...</p>
        </div>
      </section>
    );
  }

  return (
    <section className="container px-4 py-20">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-16"
      >
        <h2 className="text-3xl md:text-4xl font-bold mb-4">Latest Blog Posts</h2>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Stay updated with the latest insights, tutorials, and industry trends in web development and SaaS.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        {posts.map((post, index) => (
          <motion.div
            key={post.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="glass glass-hover h-full">
              <CardHeader>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                  <Calendar className="w-4 h-4" />
                  {formatDate(post.published)}
                </div>
                <h3 className="text-xl font-semibold line-clamp-2">{post.title}</h3>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4 line-clamp-3">
                  {stripHtml(post.content)}
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <User className="w-4 h-4" />
                    {post.author.displayName}
                  </div>
                  <Button variant="ghost" size="sm" asChild>
                    <a href={`/blog/${post.id}`}>
                      Read More <ArrowRight className="ml-1 w-4 h-4" />
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="text-center">
        <Button asChild className="button-gradient">
          <a href="/blog">
            View All Posts <ArrowRight className="ml-2 w-4 h-4" />
          </a>
        </Button>
      </div>
    </section>
  );
};

export default BlogSection;
