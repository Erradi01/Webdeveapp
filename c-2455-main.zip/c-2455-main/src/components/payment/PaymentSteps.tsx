
import { useState } from "react";
import { Check, CreditCard, User, FileText, CheckCircle, ArrowRight, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface PaymentStepsProps {
  currentStep: number;
  totalSteps: number;
  stepTitles: string[];
}

export const PaymentSteps = ({ currentStep, totalSteps, stepTitles }: PaymentStepsProps) => {
  const icons = [User, CreditCard, FileText, CheckCircle];

  return (
    <div className="w-full py-6">
      <div className="flex items-center justify-between relative">
        {/* Progress Line */}
        <div className="absolute top-5 left-0 w-full h-0.5 bg-white/10">
          <div 
            className="h-full bg-primary transition-all duration-500"
            style={{ width: `${((currentStep - 1) / (totalSteps - 1)) * 100}%` }}
          />
        </div>

        {/* Steps */}
        {stepTitles.map((title, index) => {
          const stepNumber = index + 1;
          const isCompleted = stepNumber < currentStep;
          const isCurrent = stepNumber === currentStep;
          const Icon = icons[index] || User;

          return (
            <div key={stepNumber} className="flex flex-col items-center relative z-10">
              <div 
                className={cn(
                  "w-10 h-10 rounded-full flex items-center justify-center mb-2 transition-all duration-300",
                  isCompleted ? "bg-primary text-white" : 
                  isCurrent ? "bg-primary text-white shadow-lg shadow-primary/30" : 
                  "bg-white/10 text-white/50"
                )}
              >
                {isCompleted ? (
                  <Check className="w-5 h-5" />
                ) : (
                  <Icon className="w-5 h-5" />
                )}
              </div>
              <span className={cn(
                "text-xs font-medium transition-colors",
                isCurrent ? "text-primary" : 
                isCompleted ? "text-white" : "text-white/50"
              )}>
                {title}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
