
import { CheckCircle, Download, ArrowRight, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

interface PaymentSuccessProps {
  planName: string;
  amount: string;
  transactionId: string;
  onComplete: () => void;
}

export const PaymentSuccess = ({ planName, amount, transactionId, onComplete }: PaymentSuccessProps) => {
  const handleDownloadInvoice = () => {
    // Simulate invoice download
    console.log("Downloading invoice for transaction:", transactionId);
  };

  return (
    <div className="text-center space-y-6">
      <div className="flex flex-col items-center">
        <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mb-4">
          <CheckCircle className="w-10 h-10 text-green-500" />
        </div>
        <h2 className="text-3xl font-bold mb-2">Payment Successful!</h2>
        <p className="text-gray-400 max-w-md">
          Thank you for your purchase. Your subscription to the {planName} plan has been activated.
        </p>
      </div>

      <Card className="border border-white/10 bg-primary/5 max-w-md mx-auto">
        <CardContent className="p-6 space-y-4">
          <div className="flex justify-between">
            <span className="text-gray-400">Plan:</span>
            <span className="font-medium">{planName}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Amount:</span>
            <span className="font-medium">{amount}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Transaction ID:</span>
            <span className="font-medium text-sm">{transactionId}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Status:</span>
            <span className="text-green-500 font-medium">Completed</span>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        <div className="text-sm text-gray-400">
          <p>• You will receive a confirmation email shortly</p>
          <p>• Access to your plan features is now active</p>
          <p>• You can manage your subscription anytime</p>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 justify-center">
        <Button 
          onClick={handleDownloadInvoice}
          variant="outline" 
          className="border-white/10"
        >
          <Download className="mr-2 w-4 h-4" />
          Download Invoice
        </Button>
        <Button onClick={onComplete} className="button-gradient">
          <Home className="mr-2 w-4 h-4" />
          Go to Dashboard
        </Button>
      </div>
    </div>
  );
};
