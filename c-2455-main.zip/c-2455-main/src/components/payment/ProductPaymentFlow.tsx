
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CreditCard, Lock, Check, Download, Wallet, DollarSign } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface Product {
  id: string;
  title: string;
  price: number;
  category: string;
}

interface ProductPaymentFlowProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  product: Product;
}

export const ProductPaymentFlow = ({ isOpen, onClose, onSuccess, product }: ProductPaymentFlowProps) => {
  const [step, setStep] = useState<'payment' | 'processing' | 'success'>('payment');
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<'stripe' | 'paypal' | 'wise'>('stripe');
  const { toast } = useToast();

  const handlePayment = async () => {
    setIsProcessing(true);
    setStep('processing');
    
    // Simulate payment processing based on selected method
    const processingTime = selectedPaymentMethod === 'stripe' ? 2000 : 
                          selectedPaymentMethod === 'paypal' ? 3000 : 4000;
    
    await new Promise(resolve => setTimeout(resolve, processingTime));
    
    setStep('success');
    setIsProcessing(false);
    
    const paymentMethodNames = {
      stripe: 'Stripe',
      paypal: 'PayPal',
      wise: 'Wise'
    };
    
    toast({
      title: "Payment Successful!",
      description: `Payment processed via ${paymentMethodNames[selectedPaymentMethod]}. You now have access to ${product.title}`,
      duration: 5000,
    });
  };

  const handleComplete = () => {
    onSuccess();
    onClose();
    setStep('payment');
    setSelectedPaymentMethod('stripe');
  };

  const getPaymentMethodIcon = (method: string) => {
    switch (method) {
      case 'stripe':
        return <CreditCard className="w-5 h-5" />;
      case 'paypal':
        return <Wallet className="w-5 h-5" />;
      case 'wise':
        return <DollarSign className="w-5 h-5" />;
      default:
        return <CreditCard className="w-5 h-5" />;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] bg-[#121212] border border-white/10">
        <DialogHeader>
          <DialogTitle>
            {step === 'success' ? 'Purchase Complete' : 'Complete Purchase'}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {step === 'payment' && (
            <>
              {/* Product Summary */}
              <Card className="border border-white/10 bg-primary/5">
                <CardContent className="p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium">{product.title}</span>
                    <span className="text-lg font-bold text-primary">${product.price}</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {product.category === "Photography" ? "Photography Session" : "Digital Download"}
                  </p>
                </CardContent>
              </Card>

              {/* Payment Method Selection */}
              <div>
                <h3 className="text-lg font-medium mb-4">Choose Payment Method</h3>
                <Tabs value={selectedPaymentMethod} onValueChange={(value) => setSelectedPaymentMethod(value as 'stripe' | 'paypal' | 'wise')}>
                  <TabsList className="grid grid-cols-3 mb-4 bg-background/10 w-full">
                    <TabsTrigger value="stripe" className="data-[state=active]:bg-primary/20">
                      <CreditCard className="h-4 w-4 mr-2" />
                      Stripe
                    </TabsTrigger>
                    <TabsTrigger value="paypal" className="data-[state=active]:bg-primary/20">
                      <Wallet className="h-4 w-4 mr-2" />
                      PayPal
                    </TabsTrigger>
                    <TabsTrigger value="wise" className="data-[state=active]:bg-primary/20">
                      <DollarSign className="h-4 w-4 mr-2" />
                      Wise
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="stripe" className="space-y-4">
                    <Card className="border border-blue-500/20 bg-blue-500/5">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          <CreditCard className="w-8 h-8 text-blue-400" />
                          <div>
                            <h4 className="font-medium">Stripe Payment</h4>
                            <p className="text-sm text-muted-foreground">
                              Secure credit card processing with instant confirmation
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                  
                  <TabsContent value="paypal" className="space-y-4">
                    <Card className="border border-yellow-500/20 bg-yellow-500/5">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          <Wallet className="w-8 h-8 text-yellow-400" />
                          <div>
                            <h4 className="font-medium">PayPal Payment</h4>
                            <p className="text-sm text-muted-foreground">
                              Pay with your PayPal account or credit card
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                  
                  <TabsContent value="wise" className="space-y-4">
                    <Card className="border border-green-500/20 bg-green-500/5">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          <DollarSign className="w-8 h-8 text-green-400" />
                          <div>
                            <h4 className="font-medium">Wise Payment</h4>
                            <p className="text-sm text-muted-foreground">
                              International bank transfer with low fees
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </div>

              {/* Security Notice */}
              <div className="flex items-center gap-2 p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                <Lock className="w-5 h-5 text-blue-400" />
                <span className="text-sm text-blue-400">
                  Secure payment with 256-bit SSL encryption
                </span>
              </div>

              {/* Payment Button */}
              <Button 
                onClick={handlePayment}
                className="w-full button-gradient"
                size="lg"
                disabled={isProcessing}
              >
                {getPaymentMethodIcon(selectedPaymentMethod)}
                <span className="ml-2">
                  Pay ${product.price} with {selectedPaymentMethod === 'stripe' ? 'Stripe' : 
                                            selectedPaymentMethod === 'paypal' ? 'PayPal' : 'Wise'}
                </span>
              </Button>
            </>
          )}

          {step === 'processing' && (
            <div className="text-center space-y-4">
              <div className="w-16 h-16 border-4 border-primary/30 border-t-primary rounded-full animate-spin mx-auto"></div>
              <h3 className="text-lg font-medium">Processing Payment...</h3>
              <p className="text-muted-foreground">
                Processing your {selectedPaymentMethod === 'stripe' ? 'Stripe' : 
                                selectedPaymentMethod === 'paypal' ? 'PayPal' : 'Wise'} payment
              </p>
            </div>
          )}

          {step === 'success' && (
            <div className="text-center space-y-6">
              <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto">
                <Check className="w-10 h-10 text-green-500" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Payment Successful!</h3>
                <p className="text-muted-foreground">
                  Your purchase of {product.title} is complete. Payment processed via {' '}
                  {selectedPaymentMethod === 'stripe' ? 'Stripe' : 
                   selectedPaymentMethod === 'paypal' ? 'PayPal' : 'Wise'}.
                </p>
              </div>
              
              <Card className="border border-white/10 bg-green-500/5">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Download className="w-5 h-5 text-green-500" />
                    <span className="font-medium">Ready to Download</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Your files are ready for download. You'll have lifetime access to your purchase.
                  </p>
                </CardContent>
              </Card>

              <Button onClick={handleComplete} className="w-full button-gradient">
                Continue to Downloads
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
