
import { useState } from "react";
import { CreditCard, Lock, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";

interface CompletePurchaseStepProps {
  planName: string;
  amount: string;
  onPurchase: () => void;
  onBack: () => void;
  isProcessing: boolean;
}

export const CompletePurchaseStep = ({ 
  planName, 
  amount, 
  onPurchase, 
  onBack,
  isProcessing 
}: CompletePurchaseStepProps) => {
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [agreedToPrivacy, setAgreedToPrivacy] = useState(false);

  const canPurchase = agreedToTerms && agreedToPrivacy;

  const handleTermsChange = (checked: boolean | "indeterminate") => {
    setAgreedToTerms(checked === true);
  };

  const handlePrivacyChange = (checked: boolean | "indeterminate") => {
    setAgreedToPrivacy(checked === true);
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-semibold mb-2">Complete Your Purchase</h2>
        <p className="text-gray-400">Review and confirm your order</p>
      </div>

      {/* Order Summary */}
      <Card className="border border-white/10 bg-primary/5">
        <CardContent className="p-6">
          <h3 className="text-lg font-medium mb-4">Order Summary</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span>Plan:</span>
              <span className="font-medium">{planName}</span>
            </div>
            <div className="flex justify-between">
              <span>Billing:</span>
              <span>Monthly</span>
            </div>
            <div className="flex justify-between">
              <span>Setup Fee:</span>
              <span>$0.00</span>
            </div>
            <div className="border-t border-white/10 pt-3">
              <div className="flex justify-between text-lg font-semibold">
                <span>Total:</span>
                <span className="text-primary">{amount}/month</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Security Notice */}
      <div className="flex items-center gap-2 p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg">
        <Lock className="w-5 h-5 text-blue-400" />
        <span className="text-sm text-blue-400">
          Your payment is secured with 256-bit SSL encryption
        </span>
      </div>

      {/* Terms and Conditions */}
      <div className="space-y-3">
        <div className="flex items-start gap-3">
          <Checkbox 
            id="terms"
            checked={agreedToTerms}
            onCheckedChange={handleTermsChange}
            className="mt-1"
          />
          <label htmlFor="terms" className="text-sm cursor-pointer">
            I agree to the{" "}
            <a href="/terms" target="_blank" className="text-primary hover:underline">
              Terms of Service
            </a>
          </label>
        </div>
        
        <div className="flex items-start gap-3">
          <Checkbox 
            id="privacy"
            checked={agreedToPrivacy}
            onCheckedChange={handlePrivacyChange}
            className="mt-1"
          />
          <label htmlFor="privacy" className="text-sm cursor-pointer">
            I agree to the{" "}
            <a href="/privacy" target="_blank" className="text-primary hover:underline">
              Privacy Policy
            </a>
          </label>
        </div>
      </div>

      {/* Warning for incomplete agreements */}
      {!canPurchase && (
        <div className="flex items-center gap-2 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
          <AlertCircle className="w-5 h-5 text-yellow-400" />
          <span className="text-sm text-yellow-400">
            Please agree to both Terms of Service and Privacy Policy to continue
          </span>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex justify-between">
        <Button onClick={onBack} variant="outline" className="border-white/10">
          Back
        </Button>
        <Button 
          onClick={onPurchase}
          className="button-gradient"
          disabled={!canPurchase || isProcessing}
        >
          {isProcessing ? (
            <>Processing...</>
          ) : (
            <>
              <CreditCard className="mr-2 w-4 h-4" />
              Complete Purchase
            </>
          )}
        </Button>
      </div>
    </div>
  );
};
