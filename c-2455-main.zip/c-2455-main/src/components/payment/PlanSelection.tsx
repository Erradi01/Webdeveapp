
import { Check, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CardSpotlight } from "@/components/pricing/CardSpotlight";
import { cn } from "@/lib/utils";

interface Plan {
  id: string;
  name: string;
  price: string;
  description: string;
  features: string[];
  isPopular?: boolean;
}

interface PlanSelectionProps {
  selectedPlan: string | null;
  onPlanSelect: (planId: string) => void;
  onNext: () => void;
}

const plans: Plan[] = [
  {
    id: "starter",
    name: "Starter",
    price: "$29",
    description: "Perfect for freelancers and small agencies",
    features: [
      "1 SaaS application",
      "Basic customization", 
      "Up to 100 users",
      "Email support"
    ]
  },
  {
    id: "professional", 
    name: "Professional",
    price: "$79",
    description: "For growing agencies and businesses",
    features: [
      "3 SaaS applications",
      "Advanced customization",
      "Up to 1,000 users", 
      "Priority support",
      "API access"
    ],
    isPopular: true
  },
  {
    id: "enterprise",
    name: "Enterprise", 
    price: "Custom",
    description: "Tailored solutions for large organizations",
    features: [
      "Unlimited applications",
      "Full white-labeling",
      "Unlimited users",
      "Dedicated account manager",
      "Custom integrations",
      "24/7 priority support"
    ]
  }
];

export const PlanSelection = ({ selectedPlan, onPlanSelect, onNext }: PlanSelectionProps) => {
  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-semibold mb-2">Choose Your Plan</h2>
        <p className="text-gray-400">Select the perfect plan for your needs</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <div
            key={plan.id}
            className={cn(
              "cursor-pointer transition-all duration-300",
              selectedPlan === plan.id ? "transform scale-105" : ""
            )}
            onClick={() => onPlanSelect(plan.id)}
          >
            <CardSpotlight 
              className={cn(
                "border-2 h-full",
                selectedPlan === plan.id ? "border-primary bg-primary/5" : "border-white/10 hover:border-white/20",
                plan.isPopular && "ring-2 ring-primary/50"
              )}
            >
              <div className="p-6 h-full flex flex-col">
                {plan.isPopular && (
                  <span className="text-xs font-medium bg-primary/10 text-primary rounded-full px-3 py-1 w-fit mb-4">
                    Most Popular
                  </span>
                )}
                
                <h3 className="text-xl font-semibold mb-2">{plan.name}</h3>
                <div className="mb-4">
                  <span className="text-3xl font-bold">{plan.price}</span>
                  {plan.price !== "Custom" && <span className="text-gray-400">/month</span>}
                </div>
                <p className="text-gray-400 mb-6">{plan.description}</p>
                
                <ul className="space-y-3 flex-grow">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-primary flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                {selectedPlan === plan.id && (
                  <div className="mt-4 p-3 bg-primary/10 rounded-lg">
                    <p className="text-sm text-primary font-medium">✓ Selected</p>
                  </div>
                )}
              </div>
            </CardSpotlight>
          </div>
        ))}
      </div>

      {selectedPlan && (
        <div className="flex justify-center mt-8">
          <Button onClick={onNext} className="button-gradient">
            Continue to Payment Details
            <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
        </div>
      )}
    </div>
  );
};
