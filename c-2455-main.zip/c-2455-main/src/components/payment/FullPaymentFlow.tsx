import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PaymentSteps } from "./PaymentSteps";
import { PlanSelection } from "./PlanSelection";
import PaymentForm from "../pricing/PaymentForm";
import { CompletePurchaseStep } from "./CompletePurchaseStep";
import { PaymentSuccess } from "./PaymentSuccess";
import { ProductPaymentFlow } from "./ProductPaymentFlow";
import { useToast } from "@/hooks/use-toast";

interface Product {
  id: string;
  title: string;
  price: number;
  category: string;
}

interface FullPaymentFlowProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  initialPlan?: string;
  product?: Product;
}

type PaymentStep = 'plan' | 'details' | 'review' | 'success';

export const FullPaymentFlow = ({ isOpen, onClose, initialPlan, onSuccess, product }: FullPaymentFlowProps) => {
  const [currentStep, setCurrentStep] = useState<PaymentStep>('plan');
  const [selectedPlan, setSelectedPlan] = useState<string | null>(initialPlan || null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [transactionId, setTransactionId] = useState<string>("");
  const { toast } = useToast();

  // If this is a product purchase, use the ProductPaymentFlow
  if (product) {
    return (
      <ProductPaymentFlow
        isOpen={isOpen}
        onClose={onClose}
        onSuccess={onSuccess || (() => {})}
        product={product}
      />
    );
  }

  const stepTitles = ['Plan', 'Payment', 'Review', 'Complete'];
  const stepMap = { plan: 1, details: 2, review: 3, success: 4 };

  const planDetails = {
    starter: { name: "Starter", price: "$29" },
    professional: { name: "Professional", price: "$79" }, 
    enterprise: { name: "Enterprise", price: "Custom" }
  };

  const handlePlanSelect = (planId: string) => {
    setSelectedPlan(planId);
  };

  const handlePaymentSuccess = () => {
    setCurrentStep('review');
  };

  const handleCompletePurchase = async () => {
    setIsProcessing(true);
    
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const mockTransactionId = `TXN-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    setTransactionId(mockTransactionId);
    setIsProcessing(false);
    setCurrentStep('success');
    
    toast({
      title: "Payment Successful!",
      description: `Welcome to the ${planDetails[selectedPlan as keyof typeof planDetails]?.name} plan!`,
      duration: 5000,
    });
  };

  const handleFlowComplete = () => {
    onClose();
    // Reset state
    setCurrentStep('plan');
    setSelectedPlan(null);
    setTransactionId("");
  };

  const getCurrentStepContent = () => {
    switch (currentStep) {
      case 'plan':
        return (
          <PlanSelection
            selectedPlan={selectedPlan}
            onPlanSelect={handlePlanSelect}
            onNext={() => setCurrentStep('details')}
          />
        );
      
      case 'details':
        return (
          <PaymentForm
            planName={planDetails[selectedPlan as keyof typeof planDetails]?.name || ""}
            onSuccess={handlePaymentSuccess}
          />
        );
      
      case 'review':
        return (
          <CompletePurchaseStep
            planName={planDetails[selectedPlan as keyof typeof planDetails]?.name || ""}
            amount={planDetails[selectedPlan as keyof typeof planDetails]?.price || ""}
            onPurchase={handleCompletePurchase}
            onBack={() => setCurrentStep('details')}
            isProcessing={isProcessing}
          />
        );
      
      case 'success':
        return (
          <PaymentSuccess
            planName={planDetails[selectedPlan as keyof typeof planDetails]?.name || ""}
            amount={planDetails[selectedPlan as keyof typeof planDetails]?.price || ""}
            transactionId={transactionId}
            onComplete={handleFlowComplete}
          />
        );
      
      default:
        return null;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[900px] bg-[#121212] border border-white/10 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl">
            {currentStep === 'success' ? 'Payment Complete' : 'Subscribe to Plan'}
          </DialogTitle>
        </DialogHeader>
        
        {currentStep !== 'success' && (
          <PaymentSteps
            currentStep={stepMap[currentStep]}
            totalSteps={4}
            stepTitles={stepTitles}
          />
        )}
        
        <div className="mt-6">
          {getCurrentStepContent()}
        </div>
      </DialogContent>
    </Dialog>
  );
};
