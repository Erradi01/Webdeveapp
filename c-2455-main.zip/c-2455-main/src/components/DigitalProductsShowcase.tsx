import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, ShoppingCart, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import ProductDetailsModal from "@/components/ProductDetailsModal";

const DigitalProductsShowcase = () => {
  const [selectedProduct, setSelectedProduct] = useState(null);

  const featuredProducts = [
    {
      id: "1",
      title: "SaaS Website Template Pack",
      description: "Complete website templates for SaaS applications including landing pages, dashboards, and admin panels.",
      price: 49,
      image: "/lovable-uploads/c32c6788-5e4a-4fee-afee-604b03113c7f.png",
      category: "Templates",
      rating: 4.8,
      downloads: 1240,
      featured: true,
      tags: ["React", "TypeScript", "Tailwind"],
      longDescription: "This comprehensive template pack includes everything you need to build a modern SaaS application. Features responsive design, dark mode support, authentication pages, pricing sections, and more. Built with React, TypeScript, and Tailwind CSS for optimal performance and maintainability."
    },
    {
      id: "2",
      title: "React Component Library",
      description: "Professional React components library with 100+ customizable components for rapid development.",
      price: 79,
      image: "/lovable-uploads/21f3edfb-62b5-4e35-9d03-7339d803b980.png",
      category: "Components",
      rating: 4.9,
      downloads: 856,
      featured: true,
      tags: ["React", "Components", "UI"],
      longDescription: "A complete component library featuring over 100 professionally designed React components. Includes forms, navigation, data display, feedback components, and more. Fully customizable with TypeScript support and comprehensive documentation."
    },
    {
      id: "3",
      title: "Professional Portrait Photography",
      description: "High-quality portrait photography sessions for professionals, families, and personal branding.",
      price: 299,
      image: "https://images.unsplash.com/photo-1649972904349-6e44c42644a7?auto=format&fit=crop&q=80&w=800",
      category: "Photography",
      rating: 5.0,
      downloads: 45,
      featured: true,
      tags: ["Portrait", "Professional", "Studio"],
      longDescription: "Professional portrait photography sessions including consultation, 2-hour shoot, professional editing, and delivery of 20-30 high-resolution images. Perfect for LinkedIn profiles, personal branding, or family portraits."
    },
    {
      id: "4",
      title: "Event Photography Package",
      description: "Comprehensive event photography coverage for corporate events, weddings, and special occasions.",
      price: 599,
      image: "https://images.unsplash.com/photo-1523712999610-f77fbcfc3843?auto=format&fit=crop&q=80&w=800",
      category: "Photography",
      rating: 4.9,
      downloads: 28,
      featured: true,
      tags: ["Events", "Wedding", "Corporate"],
      longDescription: "Full-day event photography coverage including pre-event consultation, unlimited shots during the event, professional editing, and delivery of 100+ high-resolution images within 2 weeks."
    }
  ];

  return (
    <section className="container px-4 py-20 bg-black">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        viewport={{ once: true }}
        className="text-center mb-16"
      >
        <h2 className="text-3xl md:text-4xl font-bold mb-4">
          Premium Digital Products & Photography Services
        </h2>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Accelerate your development workflow with our carefully crafted templates, components, and professional photography services.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        {featuredProducts.map((product, index) => (
          <motion.div
            key={product.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            viewport={{ once: true }}
          >
            <Card className="glass glass-hover overflow-hidden h-full">
              <div className="relative">
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-48 object-cover"
                />
                <Badge className="absolute top-4 left-4 bg-primary">
                  Featured
                </Badge>
              </div>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-xl mb-2">{product.title}</CardTitle>
                    <Badge variant="secondary">{product.category}</Badge>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-primary">${product.price}</div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">{product.description}</p>
                {product.tags && (
                  <div className="flex flex-wrap gap-1 mb-4">
                    {product.tags.slice(0, 3).map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                )}
                <div className="flex items-center gap-4 mb-4">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-500 fill-current" />
                    <span className="text-sm">{product.rating}</span>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {product.category === "Photography" ? `${product.downloads} bookings` : `${product.downloads} downloads`}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button 
                    className="flex-1"
                    variant="outline"
                    asChild
                  >
                    <a href={`/products/${product.id}`}>
                      View Details
                    </a>
                  </Button>
                  <Button 
                    className="flex-1 button-gradient"
                    onClick={() => setSelectedProduct(product)}
                  >
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    {product.category === "Photography" ? "Book Session" : "Buy Now"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        viewport={{ once: true }}
        className="text-center"
      >
        <Button size="lg" variant="outline" asChild>
          <a href="/products">
            Explore All Products
            <ArrowRight className="ml-2 w-4 h-4" />
          </a>
        </Button>
      </motion.div>

      {/* Product Details Modal */}
      {selectedProduct && (
        <ProductDetailsModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
        />
      )}
    </section>
  );
};

export default DigitalProductsShowcase;
