
import { motion } from "framer-motion";
import { CheckCircle2, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CardSpotlight } from "../pricing/CardSpotlight";

type SaasIdeaProps = {
  index: number;
  title: string;
  description: string;
  techStack: string[];
  monetization: string[];
  icon: React.ReactNode;
};

const SaasIdea = ({ index, title, description, techStack, monetization, icon }: SaasIdeaProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      viewport={{ once: true }}
      className="w-full"
    >
      <CardSpotlight className="h-full">
        <div className="p-6 h-full flex flex-col">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 rounded-lg bg-primary/10">
              {icon}
            </div>
            <h3 className="text-xl font-medium">{title}</h3>
          </div>
          <p className="text-muted-foreground mb-6">{description}</p>
          
          <div className="mb-4">
            <h4 className="text-sm font-medium text-white mb-2">Tech Stack:</h4>
            <ul className="space-y-2">
              {techStack.map((tech, i) => (
                <li key={i} className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-primary mt-0.5" />
                  <span className="text-sm text-muted-foreground">{tech}</span>
                </li>
              ))}
            </ul>
          </div>
          
          <div className="mt-auto">
            <h4 className="text-sm font-medium text-white mb-2">Monetization:</h4>
            <ul className="space-y-2">
              {monetization.map((item, i) => (
                <li key={i} className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-primary mt-0.5" />
                  <span className="text-sm text-muted-foreground">{item}</span>
                </li>
              ))}
            </ul>
          </div>
          
          <Button variant="link" className="mt-4 text-primary p-0 h-auto w-fit" size="sm">
            Learn more <ArrowRight className="ml-1 w-3 h-3" />
          </Button>
        </div>
      </CardSpotlight>
    </motion.div>
  );
};

const saasIdeas = [
  {
    title: "Website Builder SaaS",
    description: "A drag-and-drop website builder for small businesses with customizable templates.",
    techStack: [
      "Frontend: React/Vue.js",
      "Backend: Node.js/Firebase",
      "Database: Firestore/MongoDB"
    ],
    monetization: [
      "Freemium model (free basic templates, paid premium features)",
      "Subscription ($10–$50/month for advanced features)"
    ],
    icon: <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="M20 10V7.5L14 4 8 7.5v5L14 16l6-3.5V10z"/><path d="M4 14v3.5L10 21l6-3.5v-5L10 9l-6 3.5V14z"/></svg>
  },
  {
    title: "SEO Analyzer & Audit Tool",
    description: "A tool that scans websites for SEO issues including meta tags, speed, and backlinks.",
    techStack: [
      "Python (Django/Flask) for backend analysis",
      "Lighthouse API for performance metrics"
    ],
    monetization: [
      "Free limited scans",
      "Paid detailed reports ($5–$20 per audit)"
    ],
    icon: <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="m18 3-3 9-9 3 9 3 3 9 3-9 9-3-9-3Z"/></svg>
  },
  {
    title: "Uptime Monitoring SaaS",
    description: "A service that checks clients' websites for downtime and sends instant alerts.",
    techStack: [
      "Node.js + Puppeteer for automated checks",
      "Twilio API for SMS alerts"
    ],
    monetization: [
      "Tiered pricing (e.g., $9/month for 5 websites, $29/month for 50)"
    ],
    icon: <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
  },
  {
    title: "Landing Page A/B Testing Tool",
    description: "Let users test different versions of their landing pages to optimize conversions.",
    techStack: [
      "Firebase Hosting + Google Analytics API"
    ],
    monetization: [
      "Pay-per-test ($5–$10 per A/B test)",
      "Subscription option available"
    ],
    icon: <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
  },
  {
    title: "AI-Powered Chatbot Builder",
    description: "A no-code chatbot creator for business websites (customer support, lead generation).",
    techStack: [
      "Dialogflow/OpenAI API",
      "React frontend"
    ],
    monetization: [
      "Free for basic bots",
      "$20+/month for advanced AI"
    ],
    icon: <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><circle cx="12" cy="12" r="10"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"/></svg>
  },
  {
    title: "E-Commerce Analytics Dashboard",
    description: "A dashboard for WooCommerce/Shopify stores to track sales, traffic, and inventory.",
    techStack: [
      "Shopify/WooCommerce API",
      "Chart.js for visualizations"
    ],
    monetization: [
      "Freemium (basic stats free)",
      "$15/month for advanced features"
    ],
    icon: <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>
  }
];

const SaasIdeasSection = () => {
  return (
    <section className="container px-4 py-24">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="text-center mb-16 max-w-3xl mx-auto"
      >
        <h2 className="text-5xl font-normal mb-6">
          SaaS <span className="text-gradient font-medium">App Ideas</span>
        </h2>
        <p className="text-lg text-muted-foreground">
          Enhance your webdeveapp.web.app website with these powerful SaaS solutions that can provide passive income and attract more clients.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {saasIdeas.map((idea, index) => (
          <SaasIdea
            key={index}
            index={index}
            title={idea.title}
            description={idea.description}
            techStack={idea.techStack}
            monetization={idea.monetization}
            icon={idea.icon}
          />
        ))}
      </div>
      
      <div className="mt-12 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <h3 className="text-2xl font-medium mb-6">How to Integrate SaaS into Your Site?</h3>
          <div className="flex flex-col md:flex-row justify-center gap-8 mt-8">
            <div className="glass rounded-lg p-6 text-center md:text-left">
              <div className="rounded-full bg-primary/10 w-12 h-12 flex items-center justify-center mb-4 mx-auto md:mx-0">
                <span className="font-bold text-primary">1</span>
              </div>
              <h4 className="font-medium mb-2">Add a "Tools" or "SaaS" section</h4>
              <p className="text-muted-foreground text-sm">Position it next to your existing "Services" and "Pricing" sections</p>
            </div>
            
            <div className="glass rounded-lg p-6 text-center md:text-left">
              <div className="rounded-full bg-primary/10 w-12 h-12 flex items-center justify-center mb-4 mx-auto md:mx-0">
                <span className="font-bold text-primary">2</span>
              </div>
              <h4 className="font-medium mb-2">Offer free trials</h4>
              <p className="text-muted-foreground text-sm">Attract users with no-commitment trials of your SaaS products</p>
            </div>
            
            <div className="glass rounded-lg p-6 text-center md:text-left">
              <div className="rounded-full bg-primary/10 w-12 h-12 flex items-center justify-center mb-4 mx-auto md:mx-0">
                <span className="font-bold text-primary">3</span>
              </div>
              <h4 className="font-medium mb-2">Use Stripe/PayPal</h4>
              <p className="text-muted-foreground text-sm">Implement reliable payment processing for subscriptions</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default SaasIdeasSection;
