
import { useState } from "react";
import { Search, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface ProductFilterProps {
  categories: string[];
  onFilterChange: (filters: { category: string; search: string; sortBy: string }) => void;
}

const ProductFilter = ({ categories, onFilterChange }: ProductFilterProps) => {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [sortBy, setSortBy] = useState("featured");

  const handleFilterUpdate = (newFilters: Partial<{ category: string; search: string; sortBy: string }>) => {
    const updatedFilters = {
      category: newFilters.category ?? category,
      search: newFilters.search ?? search,
      sortBy: newFilters.sortBy ?? sortBy
    };
    
    if (newFilters.category !== undefined) setCategory(newFilters.category);
    if (newFilters.search !== undefined) setSearch(newFilters.search);
    if (newFilters.sortBy !== undefined) setSortBy(newFilters.sortBy);
    
    onFilterChange(updatedFilters);
  };

  return (
    <div className="flex flex-col md:flex-row gap-4 mb-8 p-4 glass rounded-lg">
      <div className="flex-1 relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
        <Input
          placeholder="Search products..."
          value={search}
          onChange={(e) => handleFilterUpdate({ search: e.target.value })}
          className="pl-10"
        />
      </div>
      
      <Select value={category} onValueChange={(value) => handleFilterUpdate({ category: value })}>
        <SelectTrigger className="w-full md:w-48">
          <SelectValue placeholder="Category" />
        </SelectTrigger>
        <SelectContent>
          {categories.map((cat) => (
            <SelectItem key={cat} value={cat}>
              {cat}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select value={sortBy} onValueChange={(value) => handleFilterUpdate({ sortBy: value })}>
        <SelectTrigger className="w-full md:w-48">
          <SelectValue placeholder="Sort by" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="featured">Featured First</SelectItem>
          <SelectItem value="price-low">Price: Low to High</SelectItem>
          <SelectItem value="price-high">Price: High to Low</SelectItem>
          <SelectItem value="rating">Highest Rated</SelectItem>
          <SelectItem value="downloads">Most Downloaded</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
};

export default ProductFilter;
