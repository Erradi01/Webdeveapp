
import React from 'react';
import { motion } from "framer-motion";
import { CardSpotlight } from "./CardSpotlight";

interface NextStepsCardProps {
  stepNumber: number;
  title: string;
  description: string;
}

const NextStepsCard = ({ stepNumber, title, description }: NextStepsCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: stepNumber * 0.1 }}
      viewport={{ once: true }}
    >
      <CardSpotlight className="h-full border border-white/10">
        <div className="p-6">
          <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/20 mb-4">
            <span className="text-primary font-semibold">{stepNumber}</span>
          </div>
          <h4 className="text-xl font-medium mb-3">{title}</h4>
          <p className="text-gray-400">{description}</p>
        </div>
      </CardSpotlight>
    </motion.div>
  );
};

export default NextStepsCard;
