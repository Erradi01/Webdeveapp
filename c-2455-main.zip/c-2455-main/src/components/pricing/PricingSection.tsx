import { useState } from "react";
import { motion } from "framer-motion";
import { Check, CreditCard, Info, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CardSpotlight } from "./CardSpotlight";
import NextStepsCard from "./NextStepsCard";
import { useToast } from "@/hooks/use-toast";
import { FullPaymentFlow } from "../payment/FullPaymentFlow";
import { Switch } from "@/components/ui/switch";
import { 
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

const PricingTier = ({
  name,
  price,
  description,
  features,
  isPopular,
  onSelect,
}: {
  name: string;
  price: string;
  description: string;
  features: string[];
  isPopular?: boolean;
  onSelect: () => void;
}) => (
  <CardSpotlight className={`h-full ${isPopular ? "border-primary" : "border-white/10"} border-2`}>
    <div className="relative h-full p-6 flex flex-col">
      {isPopular && (
        <span className="text-xs font-medium bg-primary/10 text-primary rounded-full px-3 py-1 w-fit mb-4">
          Most Popular
        </span>
      )}
      <h3 className="text-xl font-medium mb-2">{name}</h3>
      <div className="mb-4">
        <span className="text-4xl font-bold">{price}</span>
        {price !== "Custom" && <span className="text-gray-400">/month</span>}
      </div>
      <p className="text-gray-400 mb-6">{description}</p>
      <ul className="space-y-3 mb-8 flex-grow">
        {features.map((feature, index) => (
          <li key={index} className="flex items-center gap-2">
            <Check className="w-5 h-5 text-primary" />
            <span className="text-sm text-gray-300">{feature}</span>
          </li>
        ))}
      </ul>
      <Button 
        className="button-gradient w-full" 
        onClick={onSelect}
      >
        Get Started
      </Button>
    </div>
  </CardSpotlight>
);

export const PricingSection = () => {
  const [isPaymentFlowOpen, setIsPaymentFlowOpen] = useState(false);
  const [selectedPlanForFlow, setSelectedPlanForFlow] = useState<string>("");
  const [showReseller, setShowReseller] = useState(false);
  const [activeTab, setActiveTab] = useState<string>("pricing");
  const { toast } = useToast();

  const handleSelectPlan = (planName: string) => {
    const planIdMap: { [key: string]: string } = {
      "Starter": "starter",
      "Professional": "professional", 
      "Enterprise": "enterprise"
    };
    
    setSelectedPlanForFlow(planIdMap[planName] || "starter");
    setIsPaymentFlowOpen(true);
  };

  return (
    <section className="container px-4 py-24">
      <div className="max-w-2xl mx-auto text-center mb-12">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-5xl md:text-6xl font-normal mb-6"
        >
          Choose Your{" "}
          <span className="text-gradient font-medium">SaaS Solution</span>
        </motion.h2>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.5 }}
          className="text-lg text-gray-400"
        >
          Select the perfect SaaS solution to enhance your web development services
        </motion.p>
      </div>

      <Tabs defaultValue="pricing" className="max-w-6xl mx-auto mb-12">
        <TabsList className="grid w-full grid-cols-2 mb-8">
          <TabsTrigger value="pricing" onClick={() => setActiveTab("pricing")}>Regular Pricing</TabsTrigger>
          <TabsTrigger value="reseller" onClick={() => setActiveTab("reseller")}>Reseller Program</TabsTrigger>
        </TabsList>
        
        <TabsContent value="pricing" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <PricingTier
              name="Starter"
              price="$29"
              description="Perfect for freelancers and small agencies"
              features={[
                "1 SaaS application",
                "Basic customization",
                "Up to 100 users",
                "Email support"
              ]}
              onSelect={() => handleSelectPlan("Starter")}
            />
            <PricingTier
              name="Professional"
              price="$79"
              description="For growing agencies and businesses"
              features={[
                "3 SaaS applications",
                "Advanced customization",
                "Up to 1,000 users",
                "Priority support",
                "API access"
              ]}
              isPopular
              onSelect={() => handleSelectPlan("Professional")}
            />
            <PricingTier
              name="Enterprise"
              price="Custom"
              description="Tailored solutions for large organizations"
              features={[
                "Unlimited applications",
                "Full white-labeling",
                "Unlimited users",
                "Dedicated account manager",
                "Custom integrations",
                "24/7 priority support"
              ]}
              onSelect={() => handleSelectPlan("Enterprise")}
            />
          </div>
        </TabsContent>
        
        <TabsContent value="reseller" className="mt-0">
          <div className="max-w-5xl mx-auto">
            <div className="flex flex-col md:flex-row justify-between items-center mb-8">
              <h3 className="text-3xl font-medium mb-4 md:mb-0">
                <span className="text-gradient">Reseller</span> Pricing Guide
              </h3>
              <div className="flex items-center gap-3">
                <span className="text-sm text-gray-400">Provider Cost</span>
                <Switch
                  checked={showReseller}
                  onCheckedChange={setShowReseller}
                  className="data-[state=checked]:bg-primary"
                />
                <span className="text-sm text-gray-400">Suggested Resell Price</span>
              </div>
            </div>
            
            <CardSpotlight className="w-full overflow-hidden">
              <Table>
                <TableCaption>
                  Recommended pricing strategy for reselling SaaS solutions to your clients
                </TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[150px]">Plan</TableHead>
                    <TableHead>Your Cost</TableHead>
                    <TableHead>{showReseller ? 'Suggested Price Range' : 'Features'}</TableHead>
                    <TableHead className="text-right">{showReseller ? 'Potential Profit' : 'Recommended For'}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="font-medium">Basic</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <DollarSign className="w-4 h-4 text-primary" />
                        <span>29/month</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {showReseller ? (
                        <div className="flex items-center gap-1">
                          <span>$59–$99/month</span>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Info className="w-4 h-4 text-muted-foreground cursor-help" />
                              </TooltipTrigger>
                              <TooltipContent className="max-w-xs">
                                <p>Price higher if offering additional services like setup and maintenance.</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      ) : (
                        <span>1 App, 100 users, basic features, branding limited</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      {showReseller ? (
                        <span className="text-emerald-400">$30–$70 per client</span>
                      ) : (
                        <span>Freelancers, small businesses</span>
                      )}
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Pro</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <DollarSign className="w-4 h-4 text-primary" />
                        <span>79/month</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {showReseller ? (
                        <div className="flex items-center gap-1">
                          <span>$149–$249/month</span>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Info className="w-4 h-4 text-muted-foreground cursor-help" />
                              </TooltipTrigger>
                              <TooltipContent className="max-w-xs">
                                <p>You can add a one-time setup fee of $250-500 in addition to monthly costs.</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      ) : (
                        <span>3 Apps, 1,000 users, better design, API access, your branding</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      {showReseller ? (
                        <span className="text-emerald-400">$70–$170 per client</span>
                      ) : (
                        <span>Growing businesses, mid-market</span>
                      )}
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Enterprise</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <DollarSign className="w-4 h-4 text-primary" />
                        <span>~300/month</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {showReseller ? (
                        <div className="flex items-center gap-1">
                          <span>$500–$1,500+/month</span>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Info className="w-4 h-4 text-muted-foreground cursor-help" />
                              </TooltipTrigger>
                              <TooltipContent className="max-w-xs">
                                <p>Consider adding a $1,000+ setup fee and annual contracts for enterprise clients.</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      ) : (
                        <span>Unlimited apps, white-label, custom features, full branding, 24/7 support</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      {showReseller ? (
                        <span className="text-emerald-400">$200–$1,200+ per client</span>
                      ) : (
                        <span>Large businesses, enterprises</span>
                      )}
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardSpotlight>
            
            <div className="mt-8 p-6 rounded-lg glass border border-white/10">
              <h4 className="text-xl font-medium mb-4">What to Include in Your Pricing</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Check className="w-5 h-5 text-primary" />
                    <span>Setup and customization time</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-5 h-5 text-primary" />
                    <span>Hosting (if applicable)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-5 h-5 text-primary" />
                    <span>Technical support services</span>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Check className="w-5 h-5 text-primary" />
                    <span>Branding and domain setup</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-5 h-5 text-primary" />
                    <span>One-time setup fees ($100–$1,000+)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-5 h-5 text-primary" />
                    <span>Profit margin (2–5× base cost)</span>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-center mt-8">
                <Button 
                  className="button-gradient" 
                  onClick={() => handleSelectPlan("Reseller")}
                >
                  Become a Reseller
                </Button>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
              <Card className="bg-black border border-white/10">
                <CardHeader>
                  <CardTitle>Getting Started</CardTitle>
                  <CardDescription>What you'll need to become a reseller</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Check className="w-5 h-5 text-primary" />
                    <span>Active SaaS subscription</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-5 h-5 text-primary" />
                    <span>Business entity (recommended)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-5 h-5 text-primary" />
                    <span>Client onboarding process</span>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-black border border-white/10">
                <CardHeader>
                  <CardTitle>Setup Fees</CardTitle>
                  <CardDescription>One-time charges for new clients</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Basic Plan</span>
                    <span className="text-primary">$100–$500</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Pro Plan</span>
                    <span className="text-primary">$250–$750</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Enterprise</span>
                    <span className="text-primary">$1,000+</span>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-black border border-white/10">
                <CardHeader>
                  <CardTitle>Profit Calculator</CardTitle>
                  <CardDescription>Example monthly revenue</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>5 Basic clients</span>
                    <span className="text-emerald-400">$150–$350</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>3 Pro clients</span>
                    <span className="text-emerald-400">$210–$510</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>1 Enterprise</span>
                    <span className="text-emerald-400">$200–$1,200</span>
                  </div>
                  <div className="border-t border-white/10 pt-2 mt-2 flex justify-between font-medium">
                    <span>Monthly Profit</span>
                    <span className="text-emerald-400">$560–$2,060</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Next Steps Section */}
      <div className="mt-24 max-w-4xl mx-auto">
        <h3 className="text-3xl font-medium text-center mb-12">
          How to <span className="text-gradient">Get Started</span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <NextStepsCard
            stepNumber={1}
            title="Choose Your Plan"
            description="Select the SaaS solution that best fits your business needs and requirements."
          />
          <NextStepsCard
            stepNumber={2}
            title="Customize Your Solution"
            description="Work with our team to customize the SaaS application to match your branding and functionality needs."
          />
          <NextStepsCard
            stepNumber={3}
            title="Launch & Scale"
            description="Deploy your SaaS solution to your clients and start generating passive income."
          />
        </div>
      </div>

      {/* Full Payment Flow Dialog */}
      <FullPaymentFlow
        isOpen={isPaymentFlowOpen}
        onClose={() => setIsPaymentFlowOpen(false)}
        initialPlan={selectedPlanForFlow}
      />
    </section>
  );
};
