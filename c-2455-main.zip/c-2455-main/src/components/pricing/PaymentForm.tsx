
import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { CreditCard, DollarSign, Wallet, ArrowLeft, ArrowRight, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";

const paymentFormSchema = z.object({
  cardName: z.string().min(2, { message: "Name is required" }),
  cardNumber: z.string().min(16, { message: "Valid card number is required" }).max(19),
  expiryDate: z.string().min(5, { message: "Expiry date is required (MM/YY)" }),
  cvv: z.string().min(3, { message: "CVV must be 3 or 4 digits" }).max(4),
});

const billingFormSchema = z.object({
  billingAddress: z.string().min(1, { message: "Address is required" }),
  city: z.string().min(1, { message: "City is required" }),
  zipCode: z.string().min(1, { message: "ZIP code is required" }),
  country: z.string().min(1, { message: "Country is required" }),
});

interface PaymentFormProps {
  planName: string;
  onSuccess: () => void;
}

const PaymentForm = ({ planName, onSuccess }: PaymentFormProps) => {
  const [step, setStep] = useState<'details' | 'payment' | 'billing' | 'confirm'>('details');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'paypal' | 'bank'>('card');
  
  // Form for payment details
  const paymentForm = useForm<z.infer<typeof paymentFormSchema>>({
    resolver: zodResolver(paymentFormSchema),
    defaultValues: {
      cardName: "",
      cardNumber: "",
      expiryDate: "",
      cvv: "",
    },
  });

  // Form for billing details
  const billingForm = useForm<z.infer<typeof billingFormSchema>>({
    resolver: zodResolver(billingFormSchema),
    defaultValues: {
      billingAddress: "",
      city: "",
      zipCode: "",
      country: "",
    },
  });

  // Method to continue to next step
  const nextStep = () => {
    switch(step) {
      case 'details':
        setStep('payment');
        break;
      case 'payment':
        if (paymentForm.formState.isValid) {
          setStep('billing');
        } else {
          paymentForm.trigger();
        }
        break;
      case 'billing':
        if (billingForm.formState.isValid) {
          setStep('confirm');
        } else {
          billingForm.trigger();
        }
        break;
      case 'confirm':
        processPayment();
        break;
    }
  };

  // Method to go back to previous step
  const prevStep = () => {
    switch(step) {
      case 'payment':
        setStep('details');
        break;
      case 'billing':
        setStep('payment');
        break;
      case 'confirm':
        setStep('billing');
        break;
    }
  };

  // Process the payment
  const processPayment = async () => {
    setIsProcessing(true);
    
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    console.log("Payment processed", { 
      paymentDetails: paymentForm.getValues(),
      billingDetails: billingForm.getValues(),
      planName,
      paymentMethod
    });
    
    setIsProcessing(false);
    onSuccess();
  };

  return (
    <div className="space-y-6">
      {/* Progress Indicator */}
      <div className="flex justify-between items-center mb-6">
        {['details', 'payment', 'billing', 'confirm'].map((stepName, index) => (
          <div key={stepName} className="flex flex-col items-center">
            <div 
              className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold mb-2",
                step === stepName ? "bg-primary text-primary-foreground" : 
                (index < ['details', 'payment', 'billing', 'confirm'].indexOf(step)) ? 
                "bg-primary/70 text-primary-foreground" : "bg-background/20 text-gray-400 border border-white/10"
              )}
            >
              {index + 1}
            </div>
            <span className={cn(
              "text-xs",
              step === stepName ? "text-primary" : 
              (index < ['details', 'payment', 'billing', 'confirm'].indexOf(step)) ? 
              "text-primary/70" : "text-gray-400"
            )}>
              {stepName.charAt(0).toUpperCase() + stepName.slice(1)}
            </span>
          </div>
        ))}
      </div>

      {/* Plan Details Step */}
      {step === 'details' && (
        <div>
          <h3 className="text-lg font-medium mb-4">Plan Details</h3>
          <Card className="border border-white/10 bg-primary/5 mb-8">
            <CardContent className="p-4">
              <div className="flex justify-between">
                <span>Plan:</span>
                <span className="font-medium">{planName}</span>
              </div>
              <div className="flex justify-between mt-2">
                <span>Total:</span>
                <span className="font-medium">
                  {planName === "Starter" ? "$29/month" : 
                  planName === "Professional" ? "$79/month" : 
                  "Custom pricing"}
                </span>
              </div>
            </CardContent>
          </Card>
          <p className="text-sm text-gray-400 mb-4">
            Please review your selected plan details before proceeding to payment information.
          </p>
          <div className="flex justify-between mt-8">
            <div></div> {/* Empty div for spacing */}
            <Button onClick={nextStep} className="button-gradient">
              Continue to Payment <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Payment Method Step */}
      {step === 'payment' && (
        <div>
          <h3 className="text-lg font-medium mb-4">Payment Information</h3>
          <Form {...paymentForm}>
            <div className="space-y-4">
              <Tabs 
                defaultValue="card" 
                className="w-full"
                value={paymentMethod}
                onValueChange={(value) => setPaymentMethod(value as 'card' | 'paypal' | 'bank')}
              >
                <TabsList className="grid grid-cols-3 mb-4 bg-background/10">
                  <TabsTrigger value="card" className="data-[state=active]:bg-primary/20">
                    <CreditCard className="h-4 w-4 mr-2" /> Card
                  </TabsTrigger>
                  <TabsTrigger value="paypal" className="data-[state=active]:bg-primary/20">
                    <Wallet className="h-4 w-4 mr-2" /> PayPal
                  </TabsTrigger>
                  <TabsTrigger value="bank" className="data-[state=active]:bg-primary/20">
                    <DollarSign className="h-4 w-4 mr-2" /> Bank
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="card" className="space-y-4">
                  <FormField
                    control={paymentForm.control}
                    name="cardName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Name on Card</FormLabel>
                        <FormControl>
                          <Input placeholder="John Doe" {...field} className="bg-background/5" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={paymentForm.control}
                    name="cardNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Card Number</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="1234 5678 9012 3456" 
                            {...field} 
                            className="bg-background/5"
                            onChange={(e) => {
                              // Only allow digits and format with spaces
                              const value = e.target.value.replace(/[^\d]/g, '').replace(/(.{4})/g, '$1 ').trim();
                              field.onChange(value);
                            }}
                            maxLength={19}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="flex gap-4">
                    <FormField
                      control={paymentForm.control}
                      name="expiryDate"
                      render={({ field }) => (
                        <FormItem className="flex-1">
                          <FormLabel>Expiry Date</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="MM/YY" 
                              {...field} 
                              className="bg-background/5"
                              onChange={(e) => {
                                let value = e.target.value.replace(/[^\d]/g, '');
                                if (value.length > 2) {
                                  value = value.slice(0, 2) + '/' + value.slice(2, 4);
                                }
                                field.onChange(value);
                              }}
                              maxLength={5}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={paymentForm.control}
                      name="cvv"
                      render={({ field }) => (
                        <FormItem className="flex-1">
                          <FormLabel>CVV</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="123" 
                              {...field} 
                              className="bg-background/5"
                              type="password"
                              onChange={(e) => {
                                const value = e.target.value.replace(/[^\d]/g, '');
                                field.onChange(value);
                              }}
                              maxLength={4}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </TabsContent>
                
                <TabsContent value="paypal">
                  <div className="text-center p-8">
                    <Wallet className="w-16 h-16 mx-auto mb-4 text-primary/70" />
                    <p className="mb-2">PayPal integration coming soon</p>
                    <p className="text-sm text-gray-400">Please use card payment for now</p>
                  </div>
                </TabsContent>
                
                <TabsContent value="bank">
                  <div className="text-center p-8">
                    <DollarSign className="w-16 h-16 mx-auto mb-4 text-primary/70" />
                    <p className="mb-2">Bank transfer integration coming soon</p>
                    <p className="text-sm text-gray-400">Please use card payment for now</p>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
            <div className="flex justify-between mt-8">
              <Button onClick={prevStep} variant="outline" className="border-white/10">
                <ArrowLeft className="mr-2 h-4 w-4" /> Back
              </Button>
              <Button onClick={nextStep} className="button-gradient">
                Continue to Billing <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </Form>
        </div>
      )}

      {/* Billing Information Step */}
      {step === 'billing' && (
        <div>
          <h3 className="text-lg font-medium mb-4">Billing Information</h3>
          <Form {...billingForm}>
            <div className="space-y-4">
              <FormField
                control={billingForm.control}
                name="billingAddress"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Billing Address</FormLabel>
                    <FormControl>
                      <Input placeholder="123 Main St" {...field} className="bg-background/5" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={billingForm.control}
                  name="city"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>City</FormLabel>
                      <FormControl>
                        <Input placeholder="New York" {...field} className="bg-background/5" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={billingForm.control}
                  name="zipCode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>ZIP Code</FormLabel>
                      <FormControl>
                        <Input placeholder="10001" {...field} className="bg-background/5" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={billingForm.control}
                name="country"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Country</FormLabel>
                    <FormControl>
                      <Input placeholder="United States" {...field} className="bg-background/5" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <div className="flex justify-between mt-8">
              <Button onClick={prevStep} variant="outline" className="border-white/10">
                <ArrowLeft className="mr-2 h-4 w-4" /> Back
              </Button>
              <Button onClick={nextStep} className="button-gradient">
                Review Order <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </Form>
        </div>
      )}

      {/* Confirmation Step */}
      {step === 'confirm' && (
        <div>
          <div className="text-center mb-6">
            <CheckCircle className="w-16 h-16 text-primary mx-auto mb-4" />
            <h3 className="text-xl font-medium">Review Your Order</h3>
            <p className="text-sm text-gray-400">Please confirm your subscription details before completing your purchase</p>
          </div>
          
          <Card className="border border-white/10 bg-primary/5 mb-6">
            <CardContent className="p-4 space-y-4">
              <div>
                <h4 className="text-sm font-medium mb-2">Plan Details</h4>
                <div className="flex justify-between mb-1">
                  <span>Plan:</span>
                  <span className="font-medium">{planName}</span>
                </div>
                <div className="flex justify-between">
                  <span>Billing:</span>
                  <span className="font-medium">Monthly</span>
                </div>
              </div>
              
              <div>
                <h4 className="text-sm font-medium mb-2">Payment Method</h4>
                <div className="flex items-center gap-2">
                  {paymentMethod === 'card' && <>
                    <CreditCard className="h-4 w-4" />
                    <span>
                      {paymentForm.getValues().cardNumber?.slice(-4) ? 
                        `Card ending in ${paymentForm.getValues().cardNumber.replace(/\s/g, '').slice(-4)}` : 
                        "Credit Card"}
                    </span>
                  </>}
                  {paymentMethod === 'paypal' && <>
                    <Wallet className="h-4 w-4" />
                    <span>PayPal</span>
                  </>}
                  {paymentMethod === 'bank' && <>
                    <DollarSign className="h-4 w-4" />
                    <span>Bank Transfer</span>
                  </>}
                </div>
              </div>
              
              <div>
                <h4 className="text-sm font-medium mb-2">Billing Address</h4>
                <p className="text-sm">
                  {billingForm.getValues().billingAddress}<br />
                  {billingForm.getValues().city}, {billingForm.getValues().zipCode}<br />
                  {billingForm.getValues().country}
                </p>
              </div>
              
              <div className="pt-4 border-t border-white/10">
                <div className="flex justify-between font-medium">
                  <span>Total:</span>
                  <span>
                    {planName === "Starter" ? "$29/month" : 
                    planName === "Professional" ? "$79/month" : 
                    "Custom pricing"}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="flex justify-between">
            <Button onClick={prevStep} variant="outline" className="border-white/10">
              <ArrowLeft className="mr-2 h-4 w-4" /> Back
            </Button>
            <Button 
              onClick={processPayment} 
              className="button-gradient" 
              disabled={isProcessing}
            >
              {isProcessing ? "Processing..." : "Complete Purchase"}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PaymentForm;
