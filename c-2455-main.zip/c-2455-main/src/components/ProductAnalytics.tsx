
import { TrendingUp, Eye, Download, DollarSign, Users, ShoppingCart } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface ProductAnalyticsProps {
  products: any[];
}

const ProductAnalytics = ({ products }: ProductAnalyticsProps) => {
  const totalProducts = products.length;
  const featuredProducts = products.filter(p => p.featured).length;
  
  const totalRevenue = products.reduce((sum, p) => {
    const price = typeof p.price === 'number' ? p.price : 0;
    const downloads = typeof p.downloads === 'number' ? p.downloads : 0;
    return sum + (price * downloads);
  }, 0);
  
  const totalDownloads = products.reduce((sum, p) => {
    const downloads = typeof p.downloads === 'number' ? p.downloads : 0;
    return sum + downloads;
  }, 0);
  
  const avgRating = products.length > 0 ? 
    products.reduce((sum, p) => {
      const rating = typeof p.rating === 'number' ? p.rating : 0;
      const currentSum = typeof sum === 'number' ? sum : 0;
      return currentSum + rating;
    }, 0) / products.length : 0;
    
  const topCategory = products.reduce((acc, p) => {
    if (p.category && typeof p.category === 'string') {
      const currentCount = Number(acc[p.category]) || 0;
      acc[p.category] = currentCount + 1;
    }
    return acc;
  }, {} as Record<string, number>);
  
  const mostPopularCategory = Object.entries(topCategory).sort(([,a], [,b]) => Number(b) - Number(a))[0];

  const stats = [
    {
      title: "Total Products",
      value: totalProducts,
      icon: ShoppingCart,
      color: "text-blue-500"
    },
    {
      title: "Featured Products",
      value: featuredProducts,
      icon: TrendingUp,
      color: "text-green-500"
    },
    {
      title: "Total Downloads",
      value: totalDownloads.toLocaleString(),
      icon: Download,
      color: "text-purple-500"
    },
    {
      title: "Estimated Revenue",
      value: `$${totalRevenue.toLocaleString()}`,
      icon: DollarSign,
      color: "text-yellow-500"
    },
    {
      title: "Average Rating",
      value: avgRating.toFixed(1),
      icon: Eye,
      color: "text-orange-500"
    },
    {
      title: "Top Category",
      value: mostPopularCategory && typeof mostPopularCategory[0] === 'string' ? mostPopularCategory[0] : "N/A",
      icon: Users,
      color: "text-cyan-500"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
      {stats.map((stat) => (
        <Card key={stat.title} className="glass glass-hover">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
            <stat.icon className={`h-4 w-4 ${stat.color}`} />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stat.value}</div>
            {stat.title === "Top Category" && mostPopularCategory && typeof mostPopularCategory[1] === 'number' && (
              <Badge variant="secondary" className="mt-1">
                {mostPopularCategory[1]} products
              </Badge>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default ProductAnalytics;
